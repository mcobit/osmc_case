READ THIS FILE CAREFULLY

Those plans are available for non-commercial use.
Feel free to adapt them to your needs.

If you want to share the plans, please share this file with them.

Martin Held (mcobit@gmx.de)

I arranged it so that it the files will fit on a DIN-A4 Page. Of course you can rearrange this as you like if you have a cutter with a bigger bed.
Materials have to be 3mm thick. I used 3mm MDF.

OSMC_case_01_engrave.svg:
Engrave this and leave in the cutter for cutting the next one.

OSMC_case_01_cut.svg:
Cut this from the previously engraved material.

OSMC_case_02.svg:
Cut this from a new sheet.

**Additional comments:**

- I am not responsible for anything you do! If you build this you need to handle **mains voltage** and this is very DANGEROUS! Do not build this if you don't know what you are doing!
- You need non-conductive spacers of 2mm height, that go between the Pi and the case.
- Use very short screws to mount the powersupply to not damage the board inside or accidentally connect mains voltage to the screws on the outside as this would trigger a breaker!
- Use M2.5 or M2 screws and nuts to mount the raspberry. All other screws and nuts are M3.


Have Fun!